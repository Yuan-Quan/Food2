# -*- coding: utf-8 -*

import os
import sys

DATA_PATH = os.path.join(sys.path[0], 'data', 'input')
MODEL_PATH = os.path.join(sys.path[0], 'data', 'output', 'model')

print(MODEL_PATH)